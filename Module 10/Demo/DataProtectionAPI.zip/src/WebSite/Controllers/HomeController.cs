﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using WebSite.Models;

namespace WebSite.Controllers
{
  public class HomeController : Controller
  {
    private IDataProtector protector;

    public HomeController(IDataProtectionProvider providor)
    {
      this.protector = providor.CreateProtector("U2U.Psst");
    }

    [Route("")]
    [Route("Psst")]
    [HttpGet]
    public IActionResult Index()
    {
      var vm = new PsstViewModel() { Secret = "Jefke" };
      return View(vm);
    }

    [Route("")]
    [Route("Psst")]
    [Route("Home/Psst")]
    [HttpPost]
    public IActionResult Index(PsstViewModel vm)
    {
      vm.EncryptedSecret = protector.Protect(vm.Secret);
      vm.DecryptedSecret = protector.Unprotect(vm.EncryptedSecret);
      vm.HashedSecret = HashSecret(vm.Secret);
      return View(vm);
    }

    private string HashSecret(string secret)
    {
      byte[] salt = new byte[256 / 8];
      using (var rng = RandomNumberGenerator.Create())
      {
        rng.GetBytes(salt);
      }
      // derive a 256-bit subkey (use HMACSHA256 with 10,000 iterations)
      string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
          password: secret,
          salt: salt,
          prf: KeyDerivationPrf.HMACSHA256,
          iterationCount: 10000,
          numBytesRequested: 256 / 8));
      return hashed;
    }

    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
