namespace WebSite.Models {
  public class PsstViewModel {
    public string Secret { get; set; }
    public string EncryptedSecret { get; set; }
    public string DecryptedSecret { get; set; }
    public string HashedSecret {get; set;}
  }
}
