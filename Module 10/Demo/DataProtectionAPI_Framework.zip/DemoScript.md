## Symmetric Encryption with DPAPI

DPAPI is an API part of Windows, which uses symmetric encryption for protecting data (especially cryptographic keys).

No need to keep track of the symmetric key, it uses the user's login or machine key.

Create an MVC web site, and add a `CryptoViewModel` class:

```
public class CryptoViewModel
{
  public string Secret { get; set; }
  public string EncryptedSecret { get; set; }
  public string DecryptedSecret { get; set; }
}
```

Add an Action with two overloaded methods:

```
[HttpGet]
public ActionResult DPAPI()
=> View(new CryptoViewModel());

[HttpPost]
public ActionResult DPAPI(CryptoViewModel vm)
{
  if (vm == null)
  {
    vm = new CryptoViewModel();
  }

  var secretBytes = Encoding.Unicode.GetBytes(vm.Secret);
  var encryptedBytes = ProtectedData.Protect(secretBytes, null, DataProtectionScope.LocalMachine);
  vm.EncryptedSecret = Encoding.Unicode.GetString(encryptedBytes);
  
  var decryptedBytes = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.LocalMachine);
  vm.DecryptedSecret = Encoding.Unicode.GetString(decryptedBytes);

  return View(vm);
}
```

Generate a View for this action and replace the `EditorFor` with `DisplayFor` for the last two properties

**Run** the application and demo.

As the last step show the difference between `DataProtectionScope.LocalMachine` and .CurrentUser
