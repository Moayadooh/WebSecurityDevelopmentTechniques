﻿using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using UsingDPAPI.Models;

namespace UsingDPAPI.Controllers
{
  public class HomeController : Controller
  {
    public ActionResult Index()
    {
      return View();
    }

    public ActionResult About()
    {
      ViewBag.Message = "Your application description page.";

      return View();
    }

    public ActionResult Contact()
    {
      ViewBag.Message = "Your contact page.";

      return View();
    }

    [HttpGet]
    public ActionResult DPAPI()
    => View(new CryptoViewModel());

    [HttpPost]
    public ActionResult DPAPI(CryptoViewModel vm)
    {
      if (vm == null)
      {
        vm = new CryptoViewModel();
      }

      var secretBytes = Encoding.Unicode.GetBytes(vm.Secret);
      var encryptedBytes = ProtectedData.Protect(secretBytes, null, DataProtectionScope.CurrentUser);
      vm.EncryptedSecret = Encoding.Unicode.GetString(encryptedBytes);

      var decryptedBytes = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.CurrentUser);
      vm.DecryptedSecret = Encoding.Unicode.GetString(decryptedBytes);

      return View(vm);
    }
  }
}