﻿namespace UsingDPAPI.Models
{
  public class CryptoViewModel
  {
    public string Secret { get; set; }
    public string EncryptedSecret { get; set; }
    public string DecryptedSecret { get; set; }
  }
}