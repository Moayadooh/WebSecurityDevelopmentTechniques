# SQL Injection demo script

This demo will illustrate the SQL injection exploit

## The exploit

1. Start the website and do a simple search for a product, for example `spread`

You get a simple list of some products

2. Now search for something by simply searching for a single quote `'; --`

Now you get a list of all the products. Why? 

3. Search again. Now only pass a single quote. 

You get a nice error (Doh!)

4. Explain that the query looks something like SELECT ? FROM ? WHERE ? LIKE %?%. Easy to deduce...

5. Try this query: `spread' AND 1 = SLEEP(2); --`

This gives you an error.. That is because this is not MYSQL. Maybe try another syntax?

6. Try: `spread'; WAITFOR DELAY '00:00:02'; --`

This works (you know after waiting 2 seconds for the query to return). So its using SQL SERVER.

7. Let's figure out which tables exist. Try `spread'; SELECT TABLE_CATALOG, TABLE_SCHEMA, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES; --`

This crashes. Probably the UNIT PRICE part. Let's fix this:

8. Try: `spread' UNION SELECT TABLE_SCHEMA, TABLE_NAME, 0 FROM INFORMATION_SCHEMA.TABLES; --`

So now we know all about the table names! It's so easy! Let's have a good look at their customers...

9 Try: spread' UNION SELECT COLUMN_NAME, DATA_TYPE, 0 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Customers'; --

This shows all the columns of the customers table, in fact any table you choose!

10: Now getting all the customer's names is easy! Imagine a table storing passwords, or credit card numbers....

## Protecing against SQL Injection

1. To start, we can convert the string concatenation to actually use a parameter. 
2. Open ProductRepository and change the query like this:

```
command.CommandText = $@"SELECT PRODUCTNAME, QUANTITYPERUNIT, UNITPRICE 
                         FROM PRODUCTS WHERE PRODUCTNAME LIKE @pattern";
```

3. Change the command to take a parameter:

```
command.Parameters.Add("pattern", sqlDbType: System.Data.SqlDbType.VarChar).Value = $"%{containing}%";
```

4. **Run** the site, and search for `spread`. This still works.
5. Let's try `'; --`. Now we don't get anything, because there is no product containing that string in it's name
6. Let's do some more **defense in depth** by validating the input using a regular expression
7. We'll restrict the search to only allow for alphanumberic input. 
8. So let's check using this **regular expression** at the beginning of the `Search` method:
```
public List<Product> Search(string containing)
{
  var regEx = new Regex(@"^[\w]+$");
  if( string.IsNullOrEmpty(containing) || !regEx.IsMatch(containing))
  {
    throw new ArgumentException("Pattern should only contain alphanumeric characters", paramName: nameof(containing));
  }
```
9. Of course running the site with a bad pattern will now result in an error screen so let's fix that too in the Controller:
```
[HttpPost]
[Route("Search")]
public ActionResult Search(SearchViewModel vm)
{
  try
  {
    var repo = new ProductsRepository();
    vm.Products = repo.Search(vm.Contains);
    return View(vm);
  }
  catch
  {
    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
  }
}
```






