﻿using SqlInjectionDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SqlInjectionDemo.Controllers
{
  public class ProductsController : Controller
  {
    private readonly static SearchViewModel Empty = new SearchViewModel();
    // GET: Products
    public ActionResult Index()
    {
      return View();
    }

    [HttpGet]
    [Route("Search")]
    public ActionResult Search() => View(Empty);

    [HttpPost]
    [Route("Search")]
    public ActionResult Search(SearchViewModel vm)
    {
      var repo = new ProductsRepository();
      vm.Products = repo.Search(vm.Contains);
      return View(vm);
    }
  }
}