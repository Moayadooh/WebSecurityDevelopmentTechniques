﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SqlInjectionDemo.Models
{
  public class Product
  {
    public int ProductID { get; set; }
    public string Name { get; set; }
    public string QtyPerUnit { get; set; }
    public string UnitPrice { get; set; }
  }
}