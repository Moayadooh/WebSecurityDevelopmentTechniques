﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace SqlInjectionDemo.Models
{
  public class ProductsRepository
  {
    public List<Product> Search(string containing)
    {
      var result = new List<Product>();
      var connection = ConfigurationManager.ConnectionStrings["Northwind"];
      using (var conn = new SqlConnection(connection.ConnectionString))
      {
        conn.Open();

        var command = new SqlCommand() { Connection = conn };
        command.CommandText = $@"SELECT PRODUCTNAME, QUANTITYPERUNIT, UNITPRICE 
                                FROM PRODUCTS WHERE PRODUCTNAME LIKE '%{containing}%'";
        using (var cmdReader = command.ExecuteReader())
        {
          while (cmdReader.Read())
          {
            var product = new Product();
            product.Name = cmdReader["PRODUCTNAME"].ToString();
            product.QtyPerUnit = cmdReader["QUANTITYPERUNIT"].ToString();
            product.UnitPrice = cmdReader["UNITPRICE"].ToString();
            result.Add(product);
          }
        }
      }
      return result;
    }
  }
}