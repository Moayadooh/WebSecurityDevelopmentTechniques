﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CrossSiteScripting.Models;
using System.Net;
using Microsoft.AspNetCore.Http;

namespace CrossSiteScripting.Controllers
{
  public class HomeController : Controller
  {
    private CrossSiteScriptingDbContext db;
    
    public HomeController(CrossSiteScriptingDbContext db)
    => this.db = db;

    public IActionResult Index()
    {
      return View();
    }

    public IActionResult About()
    {
      ViewData["Message"] = "Your application description page.";

      return View();
    }

    public IActionResult Contact()
    {
      ViewData["Message"] = "Your contact page.";

      return View();
    }

    public IActionResult Error()
    {
      return View();
    }

    private const string secretCookieName = "U2U-secret";

    private void UpdateCookies()
    {
      var secretCookie = Request.Cookies[secretCookieName];
      if (secretCookie == null)
      {
        var cookieOptions = new CookieOptions();
        cookieOptions.Expires = DateTime.Now.AddHours(1);
        Response.Cookies.Append(secretCookieName, "Visits=1", cookieOptions);
      }
      else
      {
        string[] split = secretCookie.Split('=');
        int visits = int.Parse(split.Last());
        Response.Cookies.Append(secretCookieName, $"Visits={visits+1}");
      }
    }

    [HttpGet]
    public IActionResult Blogs()
    {
      UpdateCookies();

      var vm = new BlogViewModel
      {
        Comments = db.Comments.ToList(),
        Comment = new BlogComment()
      };

      return View(vm);
    }

    [HttpPost]
    public IActionResult Blogs(BlogViewModel vm)
    {
      UpdateCookies();

      vm.Comment.Posted = DateTime.Now;
      db.Comments.Add(vm.Comment);
      db.SaveChanges();

      return Blogs();
    }
  }
}
