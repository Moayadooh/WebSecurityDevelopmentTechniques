﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using CrossSiteScripting.Models;

namespace CrossSiteScripting.Migrations
{
    [DbContext(typeof(CrossSiteScriptingDbContext))]
    [Migration("20170301094406_Created")]
    partial class Created
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.0-rtm-22752")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("CrossSiteScripting.Models.BlogComment", b =>
                {
                    b.Property<int>("ID")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Contents");

                    b.Property<string>("FromUser");

                    b.Property<DateTime>("Posted");

                    b.HasKey("ID");

                    b.ToTable("Comments");
                });
        }
    }
}
