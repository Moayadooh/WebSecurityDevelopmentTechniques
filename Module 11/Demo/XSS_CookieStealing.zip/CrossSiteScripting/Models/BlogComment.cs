﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrossSiteScripting.Models
{
  public class BlogComment
  {
    public int ID { get; set; }
    public string Contents { get; set; }
    public string FromUser { get; set; }
    public DateTime Posted { get; set; }
  }
}
