﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrossSiteScripting.Models
{
  public class BlogViewModel
  {
    public List<BlogComment> Comments { get; set; }

    public BlogComment Comment { get; set; }
  }
}
