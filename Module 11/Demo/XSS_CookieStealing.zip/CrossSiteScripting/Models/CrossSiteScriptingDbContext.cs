﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrossSiteScripting.Models
{
  public class CrossSiteScriptingDbContext : DbContext
  {
    public CrossSiteScriptingDbContext(DbContextOptions<CrossSiteScriptingDbContext> options) 
    : base(options) { }

    public DbSet<BlogComment> Comments { get; set; }
  }
}
