﻿namespace ManualEncoding.Models
{
  public class ViewModel
  {
    public string Contents { get; set; } = "<script>alert('Okilidokili!');</script>";
  }
}