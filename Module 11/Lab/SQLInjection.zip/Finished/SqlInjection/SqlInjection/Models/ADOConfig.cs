﻿namespace SqlInjection.Models
{
  public class ADOConfig
  {
    public string ConnectionString { get; set; }
  }
}
