# Encrypting and decrypting configuration sections

## Setup

Make sure this website it running inside IIS

Open command line and change to directory 

```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319>
```

## Encryption

Run following command:

```
aspnet_regiis -app /EncryptedConfig -pe connectionStrings
```

## Decryption

Run following command:

```
aspnet_regiis -app /EncryptedConfig -pd connectionStrings
```
