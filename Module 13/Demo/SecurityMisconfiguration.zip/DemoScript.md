## Security Misconfiguration Demo Script

Start by running the website. It shows a list of products.

Now go to `/products/index/4`. It shows a list of products, now from another category.

Now try `/products/index/x`. You get an error **Input string was not in a correct format**

You get a detailed error page, showing all kinds of gory details, in this case even the connection string!

## Disabling the debugger yellow screen of death

So let's change the default error handler.

Open `web.config` and add the `customErrors` element

```
<customErrors mode="On" />
```

**Run** the website again with the bad url. Now you will be redirected to the proper error page!

## Disabling logging

Let's see if logging has been turned off. Goto `/trace.axd`. You get a bunch of trace messages.

Look inside these trace messages. They contain a lot of information, some even confidential because developers need a lot of information in case something goes wrong. 

But don't leave tracing turned on in production!

You can easily turn that off in `web.config`:

```
<trace enabled="false" /> <!-- or simply delete it -->
```

**Run** again. No more logging...

## Setting Retail mode on the server

For the sake of the demo turn off custom errors

```
<customErrors mode="Off"
```

and turn on tracing

```
<trace enabled="true"/>
```

Run the web site, visit the page with the error and see full error details.
Also visit the `trace.axd` page and see the trace.

Now go to the **CONFIG** folder on your machine

Open `machine.config` and search for the `<system.web>` section.
**NOTE** that this will apply to the **whole server**!

Add a `deployment` element and set retail to true

```
<deployment retail="true" />
```

Now run the site again, visit the page with the uncaught exception.
**CustomErrors** is on, and trace.axe won't work!

## Protecting connection strings

In the first part of the demo you saw that sometimes it is easy to expose your code, so you don't want to store any secret in your code.
So what is the alternative? Storing things in `web.config` and encrypting them, which is fairly easy.

**The demo is in another project**

## Creating Trusted Connections

There is still a better way, using a **Trusted Connection**!

Open the site in **IIS**

Select **Advanced Settings**

Show the **identity** running in the **Advanced Settings** dialog

Select **Use a custom account** and select an AD account created specifically for this application.

The important thing to note is that there is no account information in the connection string!

## Using config transforms to change configuration options for deployment in production

It is easy to forget to update part of your web.config when deploying...

Start by using a **replace** transform to change customErrors

```
<customErrors mode="On" xdt:Transform="Replace">
</customErrors>
```

Now we can also **remove** the trace element using:

```
<trace xdt:Transform="Remove"/>
```

To see the effect use the **Publish** option, to file system for example.

