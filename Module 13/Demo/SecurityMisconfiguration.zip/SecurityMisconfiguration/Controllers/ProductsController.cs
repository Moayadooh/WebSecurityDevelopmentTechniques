﻿using SecurityMisconfiguration.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web.Mvc;

namespace SecurityMisconfiguration.Controllers
{
  public class ProductsController : Controller
  {
    // GET: Products
    public ActionResult Index(string id = "1")
    {
      var products = new List<Product>();
      int categoryId = int.Parse(id);
      using (var connection = new SqlConnection(@"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Northwind;Integrated Security=True"))
      {
        Trace.TraceInformation($"Open connection to {connection.ConnectionString}");
        connection.Open();
        var cmd = new SqlCommand("SELECT PRODUCTNAME, UNITPRICE FROM PRODUCTS WHERE CATEGORYID = @catid", connection);
        cmd.Parameters.Add("@catid", SqlDbType.Int).Value = categoryId;
        Trace.TraceInformation($"Executing command {cmd.CommandText}");
        var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
          var product = new Product
          {
            ProductName = (string)reader["PRODUCTNAME"],
            UnitPrice = (decimal?)reader["UNITPRICE"]
          };
          products.Add(product);
        }
      }
      return View(products);
    }
  }
}