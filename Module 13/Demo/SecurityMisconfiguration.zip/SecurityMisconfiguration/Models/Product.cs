﻿namespace SecurityMisconfiguration.Models
{
  public class Product
  {
    public string ProductName { get; set; }
    public decimal? UnitPrice { get; set; }
  }
}