﻿global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;
global using BestPractices.Configurations;
global using BestPractices.Models;
global using BestPractices.DTOs;
global using AutoMapper;