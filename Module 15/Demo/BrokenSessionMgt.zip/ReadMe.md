# Broken Session Management

## .NET Core
- See `HomeController` and `Index.cshtml`
- Run demo, it displays the "u2u" cookie
- Enable CookieOptions in `HomeController`
- Run demo, it no longer displays the "u2u" cookie
- Inspect cookie with browser tools

## .NET Framework
- See `HomeController`, `Index.cshtml` and `web.config` (root)
- Run demo, it displays the "u2u" cookie
- Enable CookieOptions in `HomeController` or by changing defaults in `web.config`
- Run demo, it no longer displays the "u2u" cookie
- Inspect cookie with browser tools