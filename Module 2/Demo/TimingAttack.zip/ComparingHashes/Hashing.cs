﻿namespace ComparingHashes;

public class Hashing
{
  private void BurnSomeCycles()
  {
    int delay = 10;
    while (delay-- > 0)
    {
      ;
    }
  }

  public bool FastCompare(byte[] left, byte[] right)
  {
    for (int i = 0; i < left.Length; i += 1)
    {
      if (left[i] != right[i])
      {
        return false;
      }
    }
    return true;
  }

  public bool ConstCompare(byte[] left, byte[] right)
  {
    int mark = 0;
    for (int i = 0; i < left.Length; i += 1)
    {
      mark |= left[i] ^ right[i];
    }
    return mark != 0;
  }

  public void PrintHash(byte[] hash, bool newLine = false)
  {
    byte[] h = hash ?? throw new ArgumentNullException(nameof(hash));

    for (int i = 0; i < hash.Length; i += 1)
    {
      Console.Write($"{hash[i]:x2}");
    }
    if (newLine) { Console.WriteLine(); }
  }
}
