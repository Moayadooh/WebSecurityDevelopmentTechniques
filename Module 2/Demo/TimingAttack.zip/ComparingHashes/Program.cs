﻿
namespace ComparingHashes;

internal class Program
{
  private const int hashSize = 32;

  private static readonly RandomNumberGenerator rnd = RandomNumberGenerator.Create();
  private static readonly Hashing hUtils = new Hashing();

  private static void InitHack(byte[] originalHash, byte[][] hack, int pos)
  {
    for (int i = 0; i < 256; i += 1)
    {
      hack[i] = new byte[hashSize];
      for (int j = 0; j < pos; j += 1)
      {
        hack[i][j] = originalHash[j];
      }
      hack[i][pos] = (byte)i;
    }
  }

  private static byte[] InitHash()
  {
    byte[] hash = new byte[hashSize];
    rnd.GetBytes(hash);
    return hash;
  }

  private static long AverageFastCompare(byte[] hack, byte[] hash, int tries = 100000)
  {
    Stopwatch sw = new();
    sw.Start();
    for (int iTry = 0; iTry < tries; iTry += 1)
    {
      hUtils.FastCompare(hack, hash);
    }
    sw.Stop();
    return sw.ElapsedTicks;
  }

  private static long AverageConstCompare(byte[] hack, byte[] hash, int tries = 100000)
  {
    Stopwatch sw = new();
    sw.Start();
    for (int iTry = 0; iTry < tries; iTry += 1)
    {
      hUtils.ConstCompare(hack, hash);
    }
    sw.Stop();
    return sw.ElapsedTicks;
  }

  //private static byte[] FindBestMatch(byte[] hash)
  //{
  //  byte[][] hack = new byte[256][];
  //  long[] timing = new long[256];
  //  int slowestIndex = -1;

  //  // warm up CLR
  //  AverageFastCompare(hash, hash, 10);
  //  AverageConstCompare(hash, hash, 10);

  //  for (int iOuter = 0; iOuter < hashSize; iOuter += 1)
  //  {
  //    InitHack(hash, hack, iOuter);
  //    long slowestTiming = 0;
  //    for (int i = 0; i < 256; i += 1)
  //    {
  //      timing[i] = AverageFastCompare(hack[i], hash);
  //      //timing[i] = AverageConstCompare(hack[i], hash);
  //      if (slowestTiming < timing[i])
  //      {
  //        slowestTiming = timing[i];
  //        slowestIndex = i;
  //      }
  //    }
  //  }
  //  return hack[slowestIndex];
  //}

  private static byte[] FindBestMatch(byte[] hash)
  {
    byte[] hack = new byte[hashSize];
    long timing;
    int slowestValue = 0;

    for (int iOuter = 0; iOuter < hashSize; iOuter += 1)
    {
      // Looking for the slowest compare for position iOuter
      long slowestTiming = 0;
      for (int i = 0; i < 256; i += 1)
      {
        hack[iOuter] = (byte)i;
        //timing = AverageFastCompare(hack, hash);
        timing = AverageConstCompare(hack, hash);
        //timing[i] = AverageConstCompare(hack[i], hash);
        if (timing > slowestTiming)
        {
          slowestTiming = timing;
          slowestValue = i;
          if (iOuter == 0)
          {
            hUtils.PrintHash(hack, newLine: true);
            Console.WriteLine($"Comp {i} to {hash[iOuter]} took {timing}");
          }
        }
      }
      hack[iOuter] = (byte)slowestValue;
    }
    return hack;
  }
  public static void SetupProcessForBestTiming()
  {
    //use the second Core/Processor for the test
    Process.GetCurrentProcess().ProcessorAffinity = new IntPtr(2);

    //prevent "Normal" Processes from interrupting Threads
    Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;
  }

  private static void Main(string[] args)
  {
    byte[] hash = InitHash();
    hUtils.PrintHash(hash, newLine: true);

    // warm up CLR
    AverageFastCompare(hash, hash, 10);
    AverageConstCompare(hash, hash, 10);

    SetupProcessForBestTiming();

    byte[] bestMatch = FindBestMatch(hash);
    hUtils.PrintHash(bestMatch);
  }
}
