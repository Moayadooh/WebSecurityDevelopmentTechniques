﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace FileEncrypt
{
  public class FileCryptor
  {
    private ISaltGenerator saltGen;
    private IKeyGenerator keyGen;
    private ISymmetricAlgorithmFactory aesFactory;

    public FileCryptor(ISaltGenerator saltGen, IKeyGenerator keyGen, ISymmetricAlgorithmFactory aesFactory)
    {
      this.saltGen = saltGen ?? throw new ArgumentNullException(nameof(saltGen));
      this.keyGen = keyGen ?? throw new ArgumentNullException(nameof(keyGen));
      this.aesFactory = aesFactory ?? throw new ArgumentNullException(nameof(keyGen));
    }

    public int EncryptFiles(EncryptOptions options)
    {
      if (options.Valid())
      {
        var salt = saltGen.GenerateSalt(options.KeyLength);
        byte[] key = keyGen.GenerateKeyFromPassword(options.Password, options.KeyLength, salt, options.Iterations);

        SymmetricAlgorithm aes = aesFactory.Create(key, options.KeyLength);
        ICryptoTransform enc = aes.CreateEncryptor();

        // Open options.OutputFile and write the salt, initialization vector and encrypted file

        return 0;
      }
      else
      {
        return -1;
      }
    }

    public int DecryptFiles(DecryptOptions options)
    {
      return -1; // Implement
    }
  }
}
