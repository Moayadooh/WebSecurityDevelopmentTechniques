﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace MembersAPI.Policies
{
  public class AzureAuthHandler : AuthorizationHandler<AzureAuthRequirement>, IAuthorizationHandler
  {
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, AzureAuthRequirement requirement)
    {
      Claim c = context.User
                       .FindFirst("http://schemas.microsoft.com/identity/claims/scope");

      if( c != null && c.Value.Contains(requirement.Permission))
      {
        context.Succeed(requirement);
      }
      return Task.CompletedTask;
    }
  }
}
