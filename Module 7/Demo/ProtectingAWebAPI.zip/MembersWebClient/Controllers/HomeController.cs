﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MembersWebClient.Models;
using MembersWebClient.Services;

namespace MembersWebClient.Controllers
{
  [Authorize]
  // To allow this application to work in step 1.1.4, we need to allow anonymous
  // Authentication is required by default in .net core 3.0
  //[AllowAnonymous]
  public class HomeController : Controller
  {
    private readonly IProductsService productsService;

    public HomeController(IProductsService productsService)
      => this.productsService = productsService;

    public async Task<IActionResult> Index()
    {
      try
      {

        var products = await this.productsService.GetProductsAsync();
        if (products != null)
        {
          return View(products);
        }
        return RedirectToAction(nameof(Error));
      }
      catch
      {
        return Challenge();
      }

    }

    public IActionResult Privacy()
    {
      return View();
    }

    [AllowAnonymous]
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
  }
}
