﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Identity.Client;
using System.Net.Http.Headers;

namespace MembersWebClient.Services
{
  public class ProductsService : IProductsService
  {
    private readonly HttpClient httpClient;
    private readonly IHttpContextAccessor contextAccessor;
    private readonly IConfidentialClientApplication application;

    public ProductsService(HttpClient httpClient,
      IHttpContextAccessor contextAccessor,
      IConfidentialClientApplication application)
    {
      this.httpClient = httpClient;
      this.contextAccessor = contextAccessor;
      this.application = application;

    }

    public async Task<List<string>> GetProductsAsync()
    {

      var account = contextAccessor.HttpContext.User.FindFirst("preferred_username")?.Value;

      var result = await application.AcquireTokenSilent(
        new[] {
          "api://105af202-71f4-4533-8df9-5c2c17f44cf6/Products.Add" ,
          "api://105af202-71f4-4533-8df9-5c2c17f44cf6/Products.List"
        }, account).ExecuteAsync();
      var accessToken = result.AccessToken;

      this.httpClient.DefaultRequestHeaders.Authorization =
        new AuthenticationHeaderValue("Bearer", accessToken);
      this.httpClient.DefaultRequestHeaders.Accept.Add(
        new MediaTypeWithQualityHeaderValue("application/json"));

      var responseMessage = await httpClient.GetAsync("https://localhost:44327/api/products");
      if (responseMessage.IsSuccessStatusCode)
      {
        var jsonResult = await responseMessage.Content.ReadAsStringAsync();
        var products = JsonSerializer.Deserialize<List<string>>(jsonResult);
        return products;
      }
      return null;
    }
  }
}
