using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MembersWebClient.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace MembersWebClient
{
  public class Startup
  {
    public Startup(IConfiguration configuration)
    {
      Configuration = configuration;
    }

    public IConfiguration Configuration { get; }

    // This method gets called by the runtime. Use this method to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
      services.AddAuthentication(AzureADDefaults.AuthenticationScheme)
          .AddAzureAD(options => Configuration.Bind("AzureAd", options));

      services.AddControllersWithViews(options =>
      {
        var policy = new AuthorizationPolicyBuilder()
                  .RequireAuthenticatedUser()
                  .Build();
        options.Filters.Add(new AuthorizeFilter(policy));
      });
      services.AddRazorPages();

      services.AddHttpClient<IProductsService, ProductsService>();
      // services.AddScoped<IProductsService, ProductsService>();


      var confClientApplicationOptions = new ConfidentialClientApplicationOptions();
      Configuration.Bind("AzureAD", confClientApplicationOptions);

      var authority =
        Configuration["AzureAD:instance"] + Configuration["AzureAD:TenantId"];

      var redirectUri = Configuration["DeployedAt"] + Configuration["AzureAD:CallbackPath"];

      var app = ConfidentialClientApplicationBuilder
        .CreateWithApplicationOptions(confClientApplicationOptions)
        .WithRedirectUri(redirectUri)
        .WithAuthority(authority)
        .Build();

      services.AddSingleton<IConfidentialClientApplication>(app);

      services.Configure<OpenIdConnectOptions>(
        AzureADDefaults.OpenIdScheme,
        options =>
        {
          options.Authority += "/v2.0";
          options.ResponseType = OpenIdConnectResponseType.CodeIdToken;

          options.Scope.Add("api://105af202-71f4-4533-8df9-5c2c17f44cf6/Products.Add");
          options.Scope.Add("api://105af202-71f4-4533-8df9-5c2c17f44cf6/Products.List");

          options.Events.OnAuthorizationCodeReceived = async context =>
          {
            var code = context.ProtocolMessage.Code;

            var result = await app.AcquireTokenByAuthorizationCode(
              options.Scope.Except(new[] { "openid", "profile", "offline_access" }),
              code).ExecuteAsync();

            context.HandleCodeRedemption(result.AccessToken, result.IdToken);
          };


        });

      services.AddHttpContextAccessor();
    }

    // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
      if (env.IsDevelopment())
      {
        app.UseDeveloperExceptionPage();
      }
      else
      {
        app.UseExceptionHandler("/Home/Error");
        // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
        app.UseHsts();
      }
      app.UseHttpsRedirection();
      app.UseStaticFiles();

      app.UseRouting();

      app.UseAuthentication();
      app.UseAuthorization();

      app.UseEndpoints(endpoints =>
      {
        endpoints.MapControllerRoute(
                  name: "default",
                  pattern: "{controller=Home}/{action=Index}/{id?}");
        endpoints.MapRazorPages();
      });
    }
  }
}
