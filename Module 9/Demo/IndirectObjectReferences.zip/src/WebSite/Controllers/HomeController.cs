﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebSite.Models;
using WebSite.ViewModels.Home;

namespace WebSite.Controllers
{
  public class HomeController : Controller
  {
    private IEmployeeRepository repository;
    private CookieOptions cookieOptions;

    public HomeController(IEmployeeRepository repository, CookieOptions cookieOptions)
    {
      this.repository = repository;
      this.cookieOptions = cookieOptions;
    }
    
    [Route("")]
    [Route("index")]
    [Route("default")]
    public IActionResult Index()
    {
      var vm = new IndexViewModel { IsAuthenticated = IsAuthenticated() };
      return View(vm);
    }

    public IActionResult About()
    {
      ViewData["Message"] = "Your application description page.";

      return View();
    }

    public IActionResult Contact()
    {
      ViewData["Message"] = "Your contact page.";

      return View();
    }

    public IActionResult Error()
    {
      return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    [HttpGet]
    [Route("login")]
    public IActionResult Login()
    {
      this.Response.Cookies.Append("Department", "Training", this.cookieOptions);
      return RedirectToAction(nameof(HomeController.Index));
    }

    [HttpGet]
    [Route("logout")]
    public IActionResult Logout()
    {
      this.Response.Cookies.Delete("Department", this.cookieOptions);
      return RedirectToAction(nameof(HomeController.Index));
    }
    
    [HttpGet]
    [Route("notallowed")]
    public IActionResult NotAllowed() => View();

    [Route("employee/{id:int:min(1)}")]
    public IActionResult EmployeeDetail(int id)
    {
      //if( !IsAuthenticated()) {
      //  return RedirectToAction(nameof(NotAllowed));
      //}
      
      var employee = this.repository.Employee(id);

      //if (employee.Department != UserDepartment())
      //{
      //  return RedirectToAction(nameof(NotAllowed));
      //}

      var vm = new EmployeeDetailViewModel();
      vm.FullName = $"{employee.FirstName} {employee.LastName}";
      vm.Department = employee.Department;
      vm.FavFood = $"/images/{employee.FavFood}";
      vm.IsAuthenticated = IsAuthenticated();
      return View(vm);
    }

    private bool IsAuthenticated()
    => this.Request.Cookies
          .Any(cookie => cookie.Key == "Department");

    private string UserDepartment()
    => this.Request.Cookies
          .First(cookie => cookie.Key == "Department").Value;
  }
}
