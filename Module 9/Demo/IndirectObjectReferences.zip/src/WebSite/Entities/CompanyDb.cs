using Microsoft.EntityFrameworkCore;

namespace WebSite.Entities {
  public class CompanyDb : DbContext
  {
    public DbSet<Employee> Employees {get;set;}

    public CompanyDb(DbContextOptions<CompanyDb> options) : base(options) {
      Database.EnsureCreated();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      modelBuilder.Entity<Employee>().HasData(
        new Employee { Id=1, FirstName="Lenford", LastName="Leonard", Department = "Training", FavFood= "Pizza.png" },
        new Employee { Id=2, FirstName="Carl", LastName="Carlson", Department = "HR", FavFood= "Prawns.JPG" }
        );
    }

  }
}
