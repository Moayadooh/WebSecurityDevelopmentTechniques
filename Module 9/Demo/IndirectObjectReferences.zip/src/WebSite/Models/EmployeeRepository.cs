using WebSite.Entities;
using System.Linq;

namespace WebSite.Models
{

  public class EmployeeRepository : IEmployeeRepository
  {
    private CompanyDb db;
    public EmployeeRepository(CompanyDb db)
    {
      this.db = db;
    }

    public Employee Employee(int id) 
    => this.db.Employees.SingleOrDefault(emp => emp.Id == id);

  }
}
