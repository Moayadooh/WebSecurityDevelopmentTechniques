namespace WebSite.Models {
  using WebSite.Entities;
  
  public interface IEmployeeRepository {
    Employee Employee(int id);
  }
}
