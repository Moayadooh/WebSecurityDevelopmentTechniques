namespace WebSite.ViewModels.Home {
  
  public class EmployeeDetailViewModel {
    public string FullName { get; set; }
    public string Department { get; set; }
    public string FavFood { get; set; }
    
    public bool IsAuthenticated { get; set; }
  }
}
