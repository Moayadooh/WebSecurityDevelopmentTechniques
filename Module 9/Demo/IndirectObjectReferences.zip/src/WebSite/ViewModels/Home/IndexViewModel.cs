namespace WebSite.ViewModels.Home {
  
  public class IndexViewModel {
    public bool IsAuthenticated { get; set; }
  }
}
