using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using U2U.AspNetCore.Security.OverPost.Models;
using U2U.AspNetCore.Security.OverPost.ViewModels;

namespace U2U.AspNetCore.Security.OverPost.Controllers
{
  [Route("api/patient")]
  public class PatientApiController : Controller
  {
    private HospitalDb db;
    private IMapper mapper;

    public PatientApiController(HospitalDb db, IMapper mapper)
    {
      this.db = db;
      this.mapper = mapper;
    }

    [HttpGet]
    public async Task<List<Patient>> Get()
        => await db.Patients.ToListAsync();

    // This method suffers from overposting, a hacker can send
    // the secret property and it will be accepted!

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] Patient patient)
    {
      if (ModelState.IsValid)
      {
        db.Patients.Add(patient);
        await db.SaveChangesAsync();
        return Ok(patient);
      }
      else
      {
        return BadRequest();
      }
    }

    // This metod is safe, because it only accepts stuff which
    // is in the PostPatientViewModel.

    //[HttpPost]
    //public async Task<IActionResult> Post([FromBody] PostPatientViewModel patientViewModel)
    //{
    //  if (ModelState.IsValid)
    //  {
    //    var patient = mapper.Map<Patient>(patientViewModel);
    //    db.Patients.Add(patient);
    //    await db.SaveChangesAsync();
    //    return Ok(patient);
    //  }
    //  else
    //  {
    //    return BadRequest();
    //  }
    //}
  }
}
