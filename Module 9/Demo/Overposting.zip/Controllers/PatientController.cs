using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using U2U.AspNetCore.Security.OverPost.Models;

namespace U2U.AspNetCore.Security.OverPost.Controllers
{
  public class PatientController : Controller
  {
    private HospitalDb db;

    public PatientController(HospitalDb db)
    {
      this.db = db;
    }

    public async Task<IActionResult> Index()
    {
      var allPatients = await db.Patients.ToListAsync();
      return View(allPatients);
    }

    [HttpGet]
    public IActionResult Create() => View();

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Patient patient)
    {
      if (ModelState.IsValid)
      {
        db.Patients.Add(patient);
        await db.SaveChangesAsync();
        return RedirectToAction(nameof(PatientController.Index));
      }
      else
      {
        return View();
      }
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int patientId)
    {
      var patient = await db.Patients.FindAsync(patientId);
      return View(patient);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int patientId, Patient patient)
    {
      return View();
    }
  }
}
