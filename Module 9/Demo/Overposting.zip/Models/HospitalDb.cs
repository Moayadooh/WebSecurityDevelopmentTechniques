using Microsoft.EntityFrameworkCore;
using U2U.AspNetCore.Security.OverPost.Models;

namespace U2U.AspNetCore.Security.OverPost
{
  public sealed class HospitalDb : DbContext
  {
    public HospitalDb() { }
    public HospitalDb(DbContextOptions<HospitalDb> options)
    : base(options)
    { }

    public DbSet<Patient> Patients { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
      optionsBuilder.UseSqlite("Data Source=hospital.db");
    }
  }
}
