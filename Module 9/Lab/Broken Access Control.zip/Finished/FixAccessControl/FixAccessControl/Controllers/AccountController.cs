﻿using FixAccessControl.Identity;
using FixAccessControl.Models.Account;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FixAccessControl.Controllers
{
  public class AccountController : Controller
  {
    private UserManager<AppUser> _userManager;
    private SignInManager<AppUser> _signInManager;


    public AccountController(SignInManager<AppUser> signInManager, UserManager<AppUser> userManager, LabManager labManager)
    {
      this._userManager = userManager;
      this._signInManager = signInManager;
      labManager.CreateUsers().Wait();
    }

    [HttpPost]
    public async Task<IActionResult> Logout(string? returnUrl = null)
    {
      await _signInManager.SignOutAsync();
      if (returnUrl != null)
      {
        return LocalRedirect(returnUrl);
      }
      else
      {
        return RedirectToAction("Login");
      }
    }

    public IActionResult AccessDenied()
    {
      return View();
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = "")
    {
      var lvm = new LoginViewModel { RedirectUrl = returnUrl };
      return View(lvm);
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel user)
    {
      var result = await _signInManager.PasswordSignInAsync(user.UserName, user.Password, isPersistent: true, lockoutOnFailure: true);
      if (result.Succeeded)
      {
        if (!string.IsNullOrWhiteSpace(user.RedirectUrl))
        {
          return Redirect(user.RedirectUrl);
        }
        return RedirectToAction("Index", "Home");
      }
      else if (result.IsLockedOut)
      {
        ModelState.AddModelError(string.Empty, "Account Locked Out!");
        return View(user);
      }
      else
      {
        ModelState.AddModelError(string.Empty, "Invalid login attempt.");
        return View(user);
      }
      
    }

    [Authorize]
    public async Task<IActionResult> Show()
    {
      var user = await _userManager.GetUserAsync(User);

      return View(new ShowUserViewModel { Email = user.Email, Salary = user.Salary, PhoneNumber = user.PhoneNumber, UserName = user.UserName });
    }

    [Authorize]
    [Authorize(policy: "AllowMultipleUsers")]
    public async Task<IActionResult> ShowAll()
    {
      var department = User.Claims.FirstOrDefault(
                                        c => c.Type == "Department")?.Value;
      IList<AppUser> selectedUsers;
      if (department != "HR")
      // We have a manager in this case who cannot see everything, only his own   
      // department!
      {
        selectedUsers = await _userManager.GetUsersForClaimAsync
                     (new System.Security.Claims.Claim("Department", department!));
      }
      else
      {
        selectedUsers = _userManager.Users.ToList();
      }
      var vm = selectedUsers.Select(
                  u => new ShowUserViewModel { Email = u.Email, Salary = u.Salary, PhoneNumber = u.PhoneNumber, UserName = u.UserName }).ToList();
      return View(vm);

    }

  }
}