﻿using FixAccessControl.Identity;
using Microsoft.AspNetCore.Identity;
using System.Linq;
using System.Threading.Tasks;

namespace FixAccessControl.Controllers
{
  public class LabManager
  {
    private UserManager<AppUser> userManager;
    private RoleManager<IdentityRole> roleManager;

    public LabManager(UserManager<AppUser> userManager, RoleManager<IdentityRole> roleManager)
    {
      this.userManager = userManager;
      this.roleManager = roleManager;
    }
    internal async Task CreateUsers()
    {
      if (userManager.Users.Any()) { return; }

      var lou = new AppUser { Email = "lou.tenant@mailinator.com", PhoneNumber = "+324326742", UserName = "lou.tenant@mailinator.com", Salary = 2000 };
      var al = new AppUser { Email = "al.k.holic@mailinator.com", PhoneNumber = "+33123445634", UserName = "al.k.holic@mailinator.com", Salary = 2500 };
      var paige = new AppUser { Email = "paige.turner@mailinator.com", PhoneNumber = "+32345875345", UserName = "paige.turner@mailinator.com", Salary = 3000 };
      var rick = new AppUser { Email = "rick.o.shae@mailinator.com", PhoneNumber = "+3243262345", UserName = "rick.o.shae@mailinator.com", Salary = 1500 };
      var robin = new AppUser { Email = "robin.banks@mailinator.com", PhoneNumber = "+3243266357", UserName = "robin.banks@mailinator.com", Salary = 2200 };
      var barb = new AppUser { Email = "barb.b.cue@mailinator.com", PhoneNumber = "+3243679342", UserName = "barb.b.cue@mailinator.com", Salary = 1900 };
      var tommy = new AppUser { Email = "tommy.gunn@mailinator.com", PhoneNumber = "+3244697869", UserName = "tommy.gunn@mailinator.com", Salary = 2020 };
      var bill = new AppUser { Email = "bill.bored@mailinator.com", PhoneNumber = "+3296784562", UserName = "bill.bored@mailinator.com", Salary = 10000 };
      var sue = new AppUser { Email = "sue.zuki@mailinator.com", PhoneNumber = "+324676789834", UserName = "sue.zuki@mailinator.com", Salary = 3100 };
      var heaven = new AppUser { Email = "heaven.lee@mailinator.com", PhoneNumber = "+321234253465", UserName = "heaven.lee@mailinator.com", Salary = 5000 };
      var user = new AppUser() { Email = "john.doe@mailinator.com", PhoneNumber = "+32123456789", UserName = "john.doe@mailinator.com", Salary = 100000 };

      var result = await userManager.CreateAsync(lou, "U2U-secret");
      result = await userManager.CreateAsync(al, "U2U-secret");
      result = await userManager.CreateAsync(rick, "U2U-secret");
      result = await userManager.CreateAsync(robin, "U2U-secret");
      result = await userManager.CreateAsync(barb, "U2U-secret");
      result = await userManager.CreateAsync(paige, "U2U-secret");
      result = await userManager.CreateAsync(tommy, "U2U-secret");
      result = await userManager.CreateAsync(bill, "U2U-secret");
      result = await userManager.CreateAsync(sue, "U2U-secret");
      result = await userManager.CreateAsync(heaven, "U2U-secret");
      result = await userManager.CreateAsync(user, "U2U-secret");

      await userManager.UpdateSecurityStampAsync(lou);
      await userManager.UpdateSecurityStampAsync(al);
      await userManager.UpdateSecurityStampAsync(paige);
      await userManager.UpdateSecurityStampAsync(rick);
      await userManager.UpdateSecurityStampAsync(robin);
      await userManager.UpdateSecurityStampAsync(barb);
      await userManager.UpdateSecurityStampAsync(tommy);
      await userManager.UpdateSecurityStampAsync(bill);
      await userManager.UpdateSecurityStampAsync(sue);
      await userManager.UpdateSecurityStampAsync(heaven);
      await userManager.UpdateSecurityStampAsync(user);

      await roleManager.CreateAsync(new IdentityRole { Name = "Manager", NormalizedName = "Manager" });

      await userManager.AddToRoleAsync(user, "Manager");
      await userManager.AddToRoleAsync(heaven, "Manager");
      await userManager.AddToRoleAsync(bill, "Manager");

      await userManager.AddClaimAsync(robin, new System.Security.Claims.Claim("Department", "HR"));
      await userManager.AddClaimAsync(rick, new System.Security.Claims.Claim("Department", "HR"));
      await userManager.AddClaimAsync(lou, new System.Security.Claims.Claim("Department", "IT"));
      await userManager.AddClaimAsync(al, new System.Security.Claims.Claim("Department", "IT"));
      await userManager.AddClaimAsync(paige, new System.Security.Claims.Claim("Department", "IT"));
      await userManager.AddClaimAsync(user, new System.Security.Claims.Claim("Department", "IT"));
      await userManager.AddClaimAsync(tommy, new System.Security.Claims.Claim("Department", "IT"));
      await userManager.AddClaimAsync(barb, new System.Security.Claims.Claim("Department", "Marketing"));
      await userManager.AddClaimAsync(sue, new System.Security.Claims.Claim("Department", "Marketing"));
      await userManager.AddClaimAsync(heaven, new System.Security.Claims.Claim("Department", "Marketing"));
    }
  }
}