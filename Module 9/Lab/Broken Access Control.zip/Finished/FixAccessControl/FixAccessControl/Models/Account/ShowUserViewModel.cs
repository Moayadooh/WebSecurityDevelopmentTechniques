﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FixAccessControl.Models.Account
{
  public class ShowUserViewModel
  {
    public string UserName { get; set; }
    public string PhoneNumber { get; set; }
    public decimal Salary { get; set; }
    public string Email { get; set; }
  }
}
