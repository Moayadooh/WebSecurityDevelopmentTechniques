﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FixAccessControl.Policies
{
  public class DepartmentMultiUsersAuthorizationHandler : AuthorizationHandler<MultiUsersRequirement>
  {
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, MultiUsersRequirement requirement)
    {
      var department = context.User.Claims.FirstOrDefault(c => c.Type == "Department")?.Value;
      if (requirement.Department == department) { context.Succeed(requirement); }
      return Task.CompletedTask;
    }
  }
}
