﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FixAccessControl.Policies
{
  public class ManagerMultiUsersAuthorizationHandler : AuthorizationHandler<MultiUsersRequirement>
  {
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, MultiUsersRequirement requirement)
    {
      if (context.User.IsInRole("Manager")) { context.Succeed(requirement); }
      return Task.CompletedTask;
    }
  }
}
