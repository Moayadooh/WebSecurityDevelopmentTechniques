﻿using Microsoft.AspNetCore.Authorization;

namespace FixAccessControl.Policies
{
  public class MultiUsersRequirement : IAuthorizationRequirement
  {
    public string Department { get; set; }
  }
}
